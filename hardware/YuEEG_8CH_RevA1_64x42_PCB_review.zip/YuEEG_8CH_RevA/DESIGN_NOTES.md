# YuEEG 8 通道非侵入式 EEG 原理图 — Rev A0

原理图初版：2026-10-24；当前原理图/PCB 修订：2026-10-25，Rev A1。KiCad 9 工程评审稿。A1 将电解电容和 RESET/BOOT 按键移到正面，每通道改成一个 SIGNAL 电极端口、公共 REF 与独立 BIAS。交付包含本地符号/封装库、初步 BOM、制造评审文件和验证记录。尚未完成制板装配与台架实测，不能据此认定可直接连接人体。

## 方案与取舍

采用 ADS1299PAG + ESP32-S3-WROOM-1-N8，8 通道同步采样、24 bit 原始数据、目标 500 SPS、默认 PGA 24 倍。面向头皮接触式电极，首版按湿式 Ag/AgCl 电极及公共参考方案设计。没有针对干电极、耳内电极或非接触电容电极完成阻抗与噪声验证。

研究依据是 BEATS 的 ADS1299 同步采集架构、OpenBCI 的开放硬件实践，以及 FreeEEG / ESP-EEG 的 ESP32 无线传输方向。本工程重新绘制电路，不是直接移植其中任一 PCB；论文性能指标也不代表本设计的实测性能。

电源使用可拆卸、带保护和均衡能力的 2S 电池包，工作范围先定为 6.4–8.4 V。模拟侧 TPS7A4901 低噪声 LDO，数字侧 TPS62160 降压。选择 2S 是为了给约 5 V 模拟电源保留压差，代价是电池与电源系统更复杂。充电器在板外，电池取下后充电。主板没有 USB 供电或充电路径。

## 六页原理图

| 文件 | 内容 |
|---|---|
| YuEEG_8CH_RevA.kicad_sch | 总览、五个子页入口 |
| inputs_1_4.kicad_sch | CH1–CH4 输入网络、U1A |
| inputs_5_8.kicad_sch | CH5–CH8 输入网络、U1B |
| afe_core.kicad_sch | U1C–E：SPI、时钟、参考、BIAS、供电去耦 |
| mcu_radio.kicad_sch | ESP32-S3、复位/下载、SPI 阻尼、UART、电池监测 |
| power.kicad_sch | 电池保护、开关、模拟 LDO、数字降压、测试点 |

红色全局标签连接跨页网络，黑色标签只在本页内连接。U1 的五个单元代表同一颗 64 引脚 ADS1299。工程自带 YuEEG 自定义符号，以及用到的 KiCad 标准符号子集，避免依赖本机全局符号表。

## 输入、参考与 BIAS

- J101–J108：每通道只有一个 SIGNAL 针脚，接采集电极，经 P 侧输入网络到 INxP。R115/R125/…/R185 为公共参考 0 Ω 跳接，默认装配，经 N 侧输入网络到 INxN。公共参考接 J201.1，独立 BIAS 电极接 J201.2。A1 没有外接 N 端口；移除参考跳接会使对应参考路径断开。负输入接 REF，不接 BIASOUT 或板上 GND。
- P/N 每条输入各串联两颗 4.99 kΩ、0.1% 电阻。两电阻之间用 BAV199 进行对地和 +5VA 的低漏电轨向钳位。BAV199 不是专用患者保护器件，也不能保证将输入限制在绝对最大额定值的轨外 0.3 V 内；ESD、过压及断电输入必须另外验证。
- 每路 47 pF C0G 共模电容，P/N 间 1 nF C0G 差模电容。忽略电极阻抗与共模电容时，差模 RC 极点约 1/(2π × 19.96 kΩ × 1 nF) = 7.97 kHz。这是射频前置滤波，不能代替 500 SPS 下的数字滤波与带外抑制验证。
- N 端通过各自输入网络接公共参考，不使用 SRB1/SRB2。电极不直接接板上 GND。
- BIAS 使用内部中点参考，BIASOUT 到 BIASINV 反馈为 1 MΩ || 1.5 nF，取自 TI 示例；输出再经过两颗 499 kΩ 到 BIAS 电极。该值仅为首版起点，必须验证人体/电极等效负载下的稳定性、摆幅与恢复时间。电阻估算不能替代泄漏电流和单故障安全验证。
- ADS1299 的 VCAP1=100 µF、VCAP2=1 µF、VCAP3=1 µF 并 100 nF、VCAP4=1 µF。VREFP 使用 10 µF 并 100 nF，VREFN 接 AVSS/GND。每组电源引脚旁各放去耦，PCB 时按引脚就近布置。

## 电源和接口

模拟标称输出为 1.194 × (1+31.6k/10k) = 4.967 V，数字标称输出为 0.8 × (1+312k/100k) = 3.296 V。这里尚未完成参考电压、电阻容差、温度和负载变化的极限分析。输入经 PTC、SS14 和电源开关；最低电池电压时还需核对 SS14 压降和 LDO 压差。

L401 采用 2.2 µH，要求饱和电流至少 2 A，输出电容 22 µF。BOM 封装是候选值，不是采购定版：必须按实际电感的 DCR/温升/饱和电流和电容直流偏压后的有效容量重新确认。特别是 TPS7A4901 的 10 µF 输出电容，需要满足手册有效容量与稳定性要求。

模拟与数字共用连续 GND 参考面，通过器件分区与回流路径控制隔离噪声；不要随意切割 ADS1299 下方参考面。无线天线置板边，按 Espressif 要求保留禁布区，降压 SW 节点远离电极输入、VREF 与 BIAS 网络。

J301 为 3.3 V UART 调试接口：1 GND、2 TX、3 RX、4 EN、5 BOOT、6 不连接，没有电源输出。连接 UART、示波器、调试器或任何外部仪器前，应断开全部电极。本设计没有实现调试口隔离。

电池电压通过 330 kΩ/100 kΩ 分压和 100 nF 滤波送 GPIO1；8.4 V 对应约 1.95 V。需要 ADC 校准。固件应在电池低于 6.4 V 时停止采集；分压器和软件阈值不能代替电池包 BMS。

## 固件适配约定

| 功能 | ESP32-S3 GPIO |
|---|---:|
| ADS DRDY | 4 |
| ADS RESET | 5 |
| ADS PWDN | 6 |
| ADS START | 7 |
| ADS CS | 10 |
| ADS MOSI | 11 |
| ADS SCLK | 12 |
| ADS MISO | 13 |
| 电池 ADC | 1 |

SPI MODE1。CLKSEL 上拉，使用 ADS1299 内部时钟，关闭 CLK 输出。启动先保持 RESET 低，供电稳定后执行手册时序；原理图预留保守的 200 ms 初始化等待，不替代各控制信号最小时序核对。

基线目标：500 SPS、CHnSET=0x60、MISC1=0x00、内部参考和 BIAS 放大器使能、BIASREF_INT=1、BIAS_SENSP=0xFF、BIAS_SENSN=0x00，默认关闭导联脱落激励。这些是待固件实现和回读验证的配置意图，不是完整可直接烧录的寄存器初始化程序。

DRDY 中断只通知采样任务，采样任务通过 SPI 获取整帧，用 FIFO 与无线发送解耦。按 int24 传输原始数据并附序号、采样率和增益元数据。当前项目已有固件不能仅改接线后直接使用；本次未修改固件。

## 验证结果与剩余工作

验证记录保存在 review/ERC.rpt 与 review/connectivity_report.json。已使用 KiCad 9.0.5 导出实际网络表，并核对 BOM 元件集合、全部 ADS1299 引脚、设计网络名及显式不连接引脚；这能够发现子页载入失败、断线与网络误连，不能证明模拟性能或人体电气安全。PDF 和 SVG 已由 KiCad 原生导出供图面复核。

制板前需完成器件精确料号/封装审查、电源极限分析和输入保护设计复核。台架至少验证供电纹波与 Wi-Fi 瞬态、输入短路噪声和频谱、已知微伏信号增益、共模范围/抑制、BIAS 环稳定性、掉电恢复与数据丢包。人体相关评估必须在独立电气安全评审后进行。

## PCB 模块化布局（2026-10-25）

最终板框包络为 **64 × 42 mm**，四层、1.6 mm 名义板厚、双面装配。原目标 56 × 35 mm 会压缩 159 个元件的装配间距、模拟输入分区和天线净空；本版保留 0603 输入网络、2.54 mm 电极排针和完整 ESP32-S3-WROOM-1 模组，因此扩大板框。

| 区域 | 布局 |
|---|---|
| 左侧 | CH8 至 CH1 自上而下排列，P/N 输入电阻和滤波形成八个重复单元；背面为轨向钳位与参考跳接 |
| 中部 | ADS1299，模拟输入面向左侧；参考、BIAS、VCAP 和去耦围绕 AFE，GPIO/配置上拉等小器件放背面 |
| 右上 | ESP32-S3-WROOM-1-N8，串联阻尼靠近模组相关输出；天线放在顶边缺口内 |
| 下方 | 模拟 LDO 与数字降压分开，降压芯片和电感局部布线；正面设 C220 电解电容、RESET 和 BOOT 按键，电源滑动开关位于背面 |
| 接口 | 电池接口在右侧，公共 REF/BIAS 在上方，台架 UART 在左下方，电源测试点沿下边缘 |

顶边有 **19.50 × 6.30 mm** 的开口，位置为相对板框左上角 X=38.55…58.05 mm、Y=0…6.30 mm，使载板不处于模组天线下方。模组天线仍在 64 × 42 mm 总包络内。模组封装自带的所有铜层/过孔/元件禁布区已保留，外壳和电池仍应避开天线净空，并实测无线距离。

- L1 / F.Cu：元件、输入扇出及主要信号/电源走线，局部接地铜。
- L2 / In1.Cu：GND 参考平面，没有信号走线；天线区按禁布要求清空。
- L3 / In2.Cu：少量信号与电源跨接。
- L4 / B.Cu：背面保护、配置、按键与开关，辅助走线及接地铜。

最终 `review/pcb_drc.json` 使用 KiCad 9.0.5 检查铜间距、短路、板边间距、焊盘/阻焊、丝印、courtyard、未连接项，并启用原理图一致性校验：违规、未连接项和一致性问题均为 0。没有通过屏蔽违规或排除网络来取得该结果。DRC 通过不能替代电路性能测试。

名义铜间距下限 0.15 mm，信号主要为 0.18–0.20 mm；电源主干主要为 0.5 mm，细间距引脚有局部缩颈。普通过孔主要为 0.60/0.30 mm，ESP32 标准封装热焊盘包含 0.60/0.20 mm 镀孔。制造商需确认 0.20 mm 孔、热焊盘、双面装配和顶边开口的工艺能力；层叠介质厚度与铜厚按所选板厂的四层 1.6 mm 工艺重新确认。本版未增加机械安装孔。

`fabrication_review/` 包含四层 Gerber、阻焊/钢网/丝印、板框、分开的 PTH/NPTH 钻孔与孔图、位置文件，供制造评审使用。PCB/原理图中的候选封装与初步 BOM 尚不构成采购定版。装配前特别复核电容有效容量、L401 精确型号/饱和电流、PTC、电池插头极性、开关和排针朝向；背面元件应按背面装配图与位置文件确认。地过孔与电容/热焊盘附近的钢网开窗应由装配方复核。

正反面布线图为 `review/PCB_top.svg` / `PCB_bottom.svg`，装配参考图为 `Assembly_top.svg` / `Assembly_bottom.svg`，三维预览为 `PCB_3D_top.png` / `PCB_3D_bottom.png`。本机缺少 L401、U401 和 SW401 对应的三维模型，这三处在预览中显示焊盘；实际封装和网络均在 PCB、装配图与 BOM 中保留。

标准封装已经按实际使用项复制到 `footprints/`，由 `fp-lib-table` 在项目内引用。测试点装配属性、输入排针外侧丝印和天线缺口处丝印做了本地调整；对应板上封装与本地库一致。`review/` 中的构建、布线与修复脚本是开发过程记录，最终 `.kicad_pcb` 是交付基准，不能仅重跑初始 `build_pcb.py` 来覆盖它。

关于 REF、BIAS、板上 GND、SRB1/SRB2 和头皮位置的详细分析、常见设备实例与资料链接，见 `EEG_REFERENCE_BIAS_ANALYSIS.md`。A1 的 8 路采集共需 8 根 SIGNAL + 1 根 REF + 1 根 BIAS 电极线，ADC 内部仍进行差分测量。

## 资料来源

1. 本地 `reference/ads1299.pdf`，TI ADS1299 Rev C，重点核对引脚表、未使用引脚建议、BIAS 与参考示例。官方：[ADS1299 数据手册](https://www.ti.com/lit/ds/symlink/ads1299.pdf)。
2. [TPS7A49 数据手册](https://www.ti.com/lit/gpn/TPS7A49)、[TPS62160 数据手册](https://www.ti.com/lit/ds/symlink/tps62160.pdf)。
3. [ESP32-S3-WROOM-1/1U 数据手册](https://www.espressif.com/sites/default/files/documentation/esp32-s3-wroom-1_wroom-1u_datasheet_en.pdf)。
4. [BAV199 数据手册](https://assets.nexperia.com/documents/data-sheet/BAV199.pdf)。
5. [BEATS 论文](https://arxiv.org/html/2203.02102v4)、[BEATS GitHub](https://github.com/buptantEEG/BEATS)。
6. [OpenBCI V3 硬件](https://github.com/OpenBCI/V3_Hardware_Design_Files)。
7. [FreeEEG / ESP32-S3](https://github.com/eric5512/FreeEEG)、[Cerelog ESP-EEG](https://github.com/Cerelog-ESP-EEG/ESP-EEG)。

标准符号子集来自本机 KiCad 9 符号库，遵循 [KiCad Libraries License（CC BY-SA 4.0 附库使用例外）](https://www.kicad.org/libraries/license/)。生成脚本保留在 review/build_schematic.py 供追溯；运行会覆盖自动生成文件，手工修改后不要直接重跑。
