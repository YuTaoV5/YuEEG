"""Independent manufacturer pin/topology checks, electrical budgets, PCB connectivity.
Static review only. Temperature/current path assumptions require physical qualification.
Run with KiCad's bundled Python. Does not use expected_connections.json.
"""
from pathlib import Path
import pcbnew as p,xml.etree.ElementTree as ET,json,hashlib,math,csv
ROOT=Path(__file__).resolve().parents[1];tree=ET.parse(ROOT/'review/netlist.xml')
nets={q.get('ref')+'.'+q.get('pin'):n.get('name') for n in tree.findall('./nets/net') for q in n.findall('node')};checks=[]
def pin(k,w):
 assert nets[k].rsplit('/',1)[-1]==w,(k,w,nets[k]);checks.append([k,w])
def part(r,values):
 for k,v in values.items():pin(r+'.'+str(k),v)
# TI BQ25886 pin table: duplicates must remain physically assigned, not only the visible symbol pin.
part('U601',{1:'USB_DM',2:'CHG_STAT',3:'CHG_CE',4:'GND',5:'GND',6:'GND',7:'CHG_TS',8:'CHG_ILIM',9:'CHG_PG',10:'CHG_ISET',11:'CHG_REGN',12:'CHG_BOOT',13:'PACK_POS',14:'PACK_POS',15:'CHG_SYS',16:'CHG_SYS',17:'CHG_SW',18:'CHG_SW',19:'GND',20:'GND',21:'CHG_PMID',22:'CHG_PMID',23:'USB5',24:'USB_DP',25:'GND'})
part('U602',{1:'DSG_GATE',2:'CHARGE_GATE',3:'PROT_VM',4:'PROT_VC',5:'PROT_VDD',6:'RAW_BMINUS'})
part('U603',{1:'BAL_VC2',2:'BAL_VC1',3:'BAL_VC1_CB',4:'BAL_CD',5:'RAW_BMINUS',6:'BAL_ENABLE',7:'BAL_VDD',8:'BAL_OV_ALARM',9:'RAW_BMINUS'})
part('U604',{1:'RUN_BASE',2:'GND',3:'RUN_UV',4:'RUN_OV',5:'PACK_POS',6:'RUN_BASE'})
part('U605',{1:'RAW_OK',2:'RAW_BMINUS',3:'BAL_UV_SENSE',4:'RAW_BMINUS',5:'RAW_BPLUS'});assert nets['U605.6'].startswith('unconnected-')
part('U606',{1:'BAL_OPTO_A',2:'CHG_PG',3:'BAL_AND_SOURCE',4:'BAL_ENABLE'})
part('J401',{1:'RAW_BPLUS',2:'RAW_MID',3:'RAW_BMINUS'});part('J602',{1:'CHG_TS',2:'GND'})
for r,source,gate in [('Q601','DSG_SOURCE','DSG_GATE'),('Q602','GND','CHARGE_GATE')]:part(r,{1:source,2:source,3:source,4:gate,5:'BMS_DRAINS'})
part('Q603',{1:'RUN_GATE',2:'RUN_SOURCES',3:'PACK_POS'});part('Q604',{1:'RUN_GATE',2:'RUN_SOURCES',3:'ACQ_INPUT'})
part('Q605',{1:'RUN_NPN_BASE',2:'GND',3:'RUN_PULLDOWN'});part('Q606',{1:'USB_INHIBIT_B',2:'GND',3:'RUN_BASE'});part('Q607',{1:'RAW_OK',2:'RAW_BMINUS',3:'BAL_AND_SOURCE'})
for r,a,c in [('R623','RAW_BMINUS','DSG_SOURCE'),('R622','GND','PROT_VM'),('R647','USB_RAW','USB_INHIBIT_B'),('R649','RUN_SOURCES','RUN_GATE'),('R650','RUN_GATE','RUN_PULLDOWN'),('R651','ACQ_INPUT','GND'),('R607','VBAT_SW','CHG_CE'),('R608','CHG_CE','GND'),('R634','BAL_VDD','BAL_ENABLE'),('C631','BAL_VC2','BAL_VC1'),('C632','BAL_VC1','RAW_BMINUS'),('C633','BAL_CD','RAW_BMINUS'),('R630','RAW_BPLUS','BAL_VC2'),('R631','RAW_MID','BAL_VC1'),('R632','RAW_MID','BAL_VC1_CB'),('R633','RAW_BPLUS','BAL_VDD'),('D606','DSG_GATE','DSG_SOURCE'),('D607','CHARGE_GATE','GND'),('D601','USB5','GND'),('F601','RAW_BPLUS','PACK_POS'),('F602','USB_RAW','USB5'),('L601','CHG_PMID','CHG_SW')]:part(r,{1:a,2:c})
part('F401',{1:'ACQ_INPUT'})
for k in ['A1','A12','B1','B12','S1']:pin('J601.'+k,'GND')
for k in ['A4','A9','B4','B9']:pin('J601.'+k,'USB_RAW')
for k,v in {'A5':'USB_CC1','B5':'USB_CC2','A6':'USB_DP','B6':'USB_DP','A7':'USB_DM','B7':'USB_DM'}.items():pin('J601.'+k,v)
part('R601',{1:'USB_CC1',2:'GND'});part('R602',{1:'USB_CC2',2:'GND'})
sys_members={k for k,v in nets.items() if v=='GND'};raw_members={k for k,v in nets.items() if v=='RAW_BMINUS'};assert not sys_members&raw_members
sysout={k for k,v in nets.items() if v.rsplit('/',1)[-1]=='CHG_SYS'};assert sysout=={'U601.15','U601.16','C605.1','C606.1'}
b=p.LoadBoard(str(ROOT/'YuEEG_8CH_RevC.kicad_pcb'));fps={f.GetReference():f for f in b.GetFootprints()};actual={}
for r,f in fps.items():
 for q in f.Pads():
  if q.GetNumber():actual.setdefault(r+'.'+q.GetNumber(),set()).add(q.GetNetname())
bad=[(k,v,actual.get(k)) for k,v in nets.items() if actual.get(k)!={v}];assert not bad,bad
for r in ['Q601','Q602']:assert fps[r].GetFPIDAsString()=='Package_SON:VSON-8_3.3x3.3mm_P0.65mm_NexFET'
for r in ['C220','SW301','SW302']:assert fps[r].GetLayer()==p.F_Cu
for r in ['U601','U602','U603','U604','U605','U606','Q601','Q602','Q603','Q604','J401','J601','J602']:assert p.ToMM(fps[r].GetPosition().y)>=150
with (ROOT/'BOM.csv').open(encoding='utf-8-sig') as f:rows={r['Reference']:r for r in csv.DictReader(f)}
assert len(rows)==len(fps)==263
for r,f in fps.items():assert rows[r]['Value']==f.GetValue() and rows[r]['Footprint']==f.GetFPIDAsString(),r
assert rows['R623']['Value']=='0.010R 1% 0.5W'
# 300mA uses a conservative nearby low-current accuracy allowance, not a guaranteed interpolation.
ichg=1140/3810;ichg_hi=ichg*1.25*1.01
rpath=.010*1.01+2*.0118*1.5+.020;min_charge_oc=.030/rpath
assert min_charge_oc>ichg_hi
pre_lo=1.185*.975*(1+27.4*.999/(10*1.001))-.00316;pre_hi=1.185*1.025*(1+27.4*1.001/(10*.999))+.00316
run_fall=(.4-.0055)*(1+1.58e6/100e3);assert run_fall-.8-pre_hi>1
drc=json.loads((ROOT/'review/pcb_drc.json').read_text(encoding='utf8'));assert all(not drc[k] for k in ['violations','unconnected_items','schematic_parity'])
project=json.loads((ROOT/'YuEEG_8CH_RevC.kicad_pro').read_text());assert project['board']['design_settings']['drc_exclusions']==[]
assert not any(not isinstance(t,p.PCB_VIA) and t.GetLayer()==p.In1_Cu for t in b.GetTracks())
report={'revision':'C','components':len(fps),'independent_battery_pin_checks':len(checks),'all_exported_ref_pin_pairs_checked':len(nets),'pcb_net_mismatches':len(bad),'topology_checks':{'common_drain_protection_NMOS':True,'common_source_acquisition_PMOS':True,'charger_SYS_only_local_capacitors':True,'raw_minus_separate_from_GND':True,'USB_inhibit_before_input_PTC':True,'balancer_USB_and_near_full_qualified':True,'electrolytic_and_buttons_TOP':True},'charge_budget':{'nominal_A':ichg,'conservative_upper_A':ichg_hi,'assumed_hot_RDS_multiplier':1.5,'assumed_additional_return_path_ohm':.020,'total_return_budget_ohm':rpath,'minimum_charge_OC_A_with_assumptions':min_charge_oc,'CV_nominal_V':8.2,'CV_datasheet_range_V':[8.159,8.241],'ILIM_nominal_A':1110/1500},'voltage_thresholds_nominal_V':{'run_falling':run_fall,'run_rising':.4*(1+15.8),'run_OV':.4*(1+20.5),'balance_falling':.3945*(1+18.1),'balance_rising':.4*(1+18.1)},'NTC_fault_normalized_TS':{'open':365e3/(365e3+9310),'short':0},'remaining_bench_assumptions':['actual 300mA current accuracy over temperature','hot MOS resistance and total return impedance','NTC R/T and JEITA boundaries','fuse I2t and battery fault energy','USB inhibit timing, bounce and backfeed','effective capacitor values and switching-loop noise'],'scope':'Static connectivity and engineering budgets; not battery/patient safety certification or physical testing','sha256_pcb':hashlib.sha256((ROOT/'YuEEG_8CH_RevC.kicad_pcb').read_bytes()).hexdigest()}
(ROOT/'review/BATTERY_ELECTRICAL_AUDIT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
