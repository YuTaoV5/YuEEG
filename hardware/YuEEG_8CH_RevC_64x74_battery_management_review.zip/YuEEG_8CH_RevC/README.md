# YuEEG Rev C：板载 2S 电池管理

用 KiCad 9 打开 `YuEEG_8CH_RevC.kicad_pro`。本版在 Rev B 双电源 EEG 板上补入 USB-C 充电、逐节保护、均衡、温度检测及充电停采控制；Rev A/B 保留供追溯。

- 64 × 74 mm、四层、263 个元件、10 页原理图；新增电池管理集中于下方。电解电容 C220 和 RESET/BOOT 按键在正面。
- 电池按用户确认的两节匹配 4.2 V 锂离子/聚合物电芯、容量至少 1000 mAh 设计。充电标称约 300 mA，保守终止电压选 8.2 V。需独立绝缘的 103AT-2 10 kΩ NTC 贴附电芯。
- **J401 已由两线接口改为三线 B+ / MID / B−。** 针号以原理图和焊盘为准，不能沿用旧线束；RAW_BMINUS 与系统 GND 不可短接。
- BQ25886 独立充电；S-8252AAY 实现逐节过充/过放、充放电过流及短路保护；BQ29209 提供约 10 mA 的匹配电芯维护均衡。USB VBUS 出现后，硬件关断采集电源。
- 模拟供电仍为 ±2.5 V，数字约 3.296 V，前级约 4.432 V；电极为 8 SIGNAL + REF + BIAS。
- 连接、阈值、容差、采购条件及台架步骤见 `BATTERY_MANAGEMENT_REVIEW.md`；原有模拟前端依据及启动时序见 `AFE_DESIGN_REVIEW.md`。

`BOM.csv` 为电气 BOM，`BOM_with_placement.csv` 以板框左上角为原点；`fabrication_review/placement.csv` 为 KiCad 原生坐标约定。`fabrication_review/` 包含 Gerber、钻孔和装配位置。原生 KiCad 文件是交付基准，不要重新执行开发迁移脚本覆盖工程。

最终 ERC、DRC、未连接项、原理图/PCB 一致性问题均为零；全部 720 组 ref.pin 与 PCB 网络核对通过。它们是静态检查，电芯采购、热测试、充放电故障注入、电源噪声、固件适配与电气安全验证仍待实物完成。**充电、调试或接有线仪器前必须移除所有电极；硬件停采不构成医疗隔离。**
