# YuEEG Rev B

最新双电源工程：用 KiCad 9 打开 `YuEEG_8CH_RevB.kicad_pro`。保留了 Rev A1 原目录供追溯。

- 原理图：`YuEEG_8CH_RevB.kicad_sch`，七页；PDF 为同名 `.pdf`。
- PCB：`YuEEG_8CH_RevB.kicad_pcb`，64 × 50 mm，四层，178 个元件。
- 模拟电源 ±2.5 V；数字约 3.296 V；前级约 4.432 V，不能把前级接到 ADS1299 AVDD。
- 电极：8 SIGNAL + REF + BIAS；每路负输入接公共 REF。电解电容和 RESET/BOOT 按键在正面。
- 详细修改依据、发现的问题、启动时序和未验证事项：`DESIGN_REVIEW.md`。
- `BOM.csv` 为电气 BOM；`BOM_with_placement.csv` 使用板框左上角为坐标原点。`fabrication_review/placement.csv` 为 KiCad 原生装配位置格式，坐标约定请按表头解读，勿混用。
- `fabrication_review/` 为制造评审输出；`review/` 内保留最终 ERC/DRC、网络核对、独立电路审核和正反面预览。原生文件是交付基准，不要重跑早期开发脚本覆盖它。

ERC/DRC/未连接/原理图一致性均为零；这只证明当前静态规则和连接检查通过。精确采购料号、实际电容容量/电感指标、台架噪声、电源瞬态、BIAS 稳定性、ESD 与电气安全评估仍待完成。现有固件没有适配或验证，不可直接用于此板。先用假负载与独立台架验证，不是人体使用放行文件。
